import 'package:flutter/material.dart';
import 'api_service.dart';

class ApiDataScreen extends StatefulWidget {
  @override
  _ApiDataScreenState createState() => _ApiDataScreenState();
}

class _ApiDataScreenState extends State<ApiDataScreen> {
  List<dynamic> _data = [];          // Full API data
  List<dynamic> _filteredData = [];   // Filtered data for search results
  bool _isLoading = true;             // Loading indicator

  @override
  void initState() {
    super.initState();
    _fetchData();
  }

  // Fetch data from API
  void _fetchData() async {
    _data = await ApiService.fetchData();
    setState(() {
      _filteredData = _data;
      _isLoading = false;
    });
  }

  // Filter data based on search query
  void _filterData(String query) {
    List<dynamic> filtered = _data.where((item) {
      String title = item['title'].toString().toLowerCase();
      return title.contains(query.toLowerCase());
    }).toList();

    setState(() {
      _filteredData = filtered;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('API Data List')),
      body: _isLoading
          ? Center(child: CircularProgressIndicator())
          : Column(
              children: [
                Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: TextField(
                    decoration: InputDecoration(
                      hintText: 'Search...',
                      border: OutlineInputBorder(),
                    ),
                    onChanged: (query) => _filterData(query), // Update list on input
                  ),
                ),
                Expanded(
                  child: ListView.builder(
                    itemCount: _filteredData.length,
                    itemBuilder: (context, index) {
                      final item = _filteredData[index];
                      return ListTile(
                        title: Text(item['title']),   
                        subtitle: Text(item['body']), 
                      );
                    },
                  ),
                ),
              ],
            ),
    );
  }
}

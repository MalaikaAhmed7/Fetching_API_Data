import 'package:flutter/material.dart';
import 'api_data_screen.dart'; // Import screen for displaying API data

void main() {
  runApp(MyApp()); // Run the app by calling MyApp
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'API Data Fetcher', // Set app title
      theme: ThemeData(primarySwatch: Colors.blue), 
      home: ApiDataScreen(), // Set ApiDataScreen as the home screen
    );
  }
}

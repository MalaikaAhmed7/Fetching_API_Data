import 'dart:convert';
import 'package:http/http.dart' as http;

class ApiService {
  // Fetch data from the API
  static Future<List<dynamic>> fetchData() async {
    final url = Uri.parse('https://jsonplaceholder.typicode.com/posts');
    final response = await http.get(url);

    if (response.statusCode == 200) {
      return json.decode(response.body); // Parse JSON if response is successful
    } else {
      throw Exception('Failed to load data'); // Handle errors
    }
  }
}

# Task 2 - Fetching API Data and Displaying in a ListView with a Search Filter

    This Flutter project demonstrates how to fetch data from an external API and display it in a ListView with a search filter. The data is fetched from a mock API (jsonplaceholder.typicode.com) and displayed dynamically in the app. A search bar allows users to filter the data as they type.

# Features:

    - Fetch data from an external API (jsonplaceholder).
    - Display the data in a ListView.
    - Implement a real-time search filter to update the displayed list.

# Getting Started: 

    To run the project, follow these steps:
       - Clone the repository.
       - Install dependencies by running flutter pub get.
       - Run the app using flutter run.

# Resources:

   - Flutter Official Documentation
   - jsonplaceholder API
